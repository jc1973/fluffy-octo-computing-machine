default['yum-epel']['repositories'] = %w(epel epel-debuginfo epel-source epel-testing epel-testing-debuginfo epel-testing-source)
