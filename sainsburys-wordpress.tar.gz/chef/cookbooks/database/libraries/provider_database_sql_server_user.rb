#
# Author:: Seth Chisamore (<schisamo@chef.io>)
# Copyright:: Copyright (c) 2011 Chef Software, Inc.
# License:: Apache License, Version 2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

require File.join(File.dirname(__FILE__), 'provider_database_sql_server')

class Chef
  class Provider
    class Database
      class SqlServerUser < Chef::Provider::Database::SqlServer
        include Chef::Mixin::ShellOut

        def load_current_resource
          Gem.clear_paths
          require 'tiny_tds'
          @current_resource = Chef::Resource::DatabaseUser.new(@new_resource.name)
          @current_resource.username(@new_resource.name)
          @current_resource
        end

        def action_create
          unless exists?(:logins)
            if @new_resource.windows_user
              db.execute("CREATE LOGIN [#{@new_resource.username}] FROM WINDOWS").do
            else
              db.execute("CREATE LOGIN [#{@new_resource.username}] WITH PASSWORD = '#{@new_resource.password}', CHECK_POLICY = OFF").do
            end
            @new_resource.updated_by_last_action(true)
          end
          unless exists?(:users)
            if @new_resource.database_name
              Chef::Log.info("#{@new_resource} creating user in '#{@new_resource.database_name}' database context.")
              db.execute("USE [#{@new_resource.database_name}]").do
            else
              Chef::Log.info("#{@new_resource} database_name not provided, creating user in global context.")
            end
            db.execute("CREATE USER [#{@new_resource.username}] FOR LOGIN [#{@new_resource.username}]").do
            @new_resource.updated_by_last_action(true)
          end
        ensure
          close
        end

        def action_drop
          if exists?(:users)
            db.execute("DROP USER [#{@new_resource.username}]").do
            @new_resource.updated_by_last_action(true)
          end
          if exists?(:logins)
            db.execute("DROP LOGIN [#{@new_resource.username}]").do
            @new_resource.updated_by_last_action(true)
          end
        ensure
          close
        end

        def action_grant
          if @new_resource.password || (@new_resource.windows_user && !exists?(:logins))
            action_create
          end
          Chef::Application.fatal!('Please provide a database_name, SQL Server does not support global GRANT statements.') unless @new_resource.database_name
          grant_statement = "GRANT #{@new_resource.privileges.join(', ')} ON DATABASE::[#{@new_resource.database_name}] TO [#{@new_resource.username}]"
          Chef::Log.info("#{@new_resource} granting access with statement [#{grant_statement}]")
          db.execute("USE [#{@new_resource.database_name}]").do
          db.execute(grant_statement).do
          @new_resource.updated_by_last_action(true)
        ensure
          close
        end

        def action_alter_roles
          if @new_resource.password || (@new_resource.windows_user && !exists?(:logins))
            action_create
          end
          Chef::Application.fatal!('Please provide a database_name, SQL Server does not support global GRANT statements.') unless @new_resource.database_name
          db.execute("USE [#{@new_resource.database_name}]").do
          @new_resource.sql_roles.each do |sql_role, role_action|
            alter_statement = "ALTER ROLE [#{sql_role}] #{role_action} MEMBER [#{@new_resource.username}]"
            Chef::Log.info("#{@new_resource} granting access with statement [#{alter_statement}]")
            db.execute(alter_statement).do
          end
          @new_resource.updated_by_last_action(true)
        ensure
          close
        end

        def action_alter_sys_roles
          if @new_resource.password || (@new_resource.windows_user && !exists?(:logins))
            action_create
          end
          server_version = db.execute("SELECT SERVERPROPERTY('productversion')").each.first.values.first
          Chef::Log.info("SQL Server Version: #{server_version.inspect}")
          db.execute('USE [master]').do
          @new_resource.sql_sys_roles.each do |sql_sys_role, role_action|
            case role_action
            when 'ADD'
              if server_version < '11.00.0000.00'
                alter_statement = "EXEC sp_addsrvrolemember '#{@new_resource.username}', '#{sql_sys_role}'"
              else
                alter_statement = "ALTER SERVER ROLE #{sql_role} #{role_action} MEMBER [#{@new_resource.username}]"
              end
              Chef::Log.info("#{@new_resource} granting server role membership with statement [#{alter_statement}]")
            when 'DROP'
              if server_version < '11.00.0000.00'
                alter_statement = "EXEC sp_dropsrvrolemember '#{@new_resource.username}', '#{sql_sys_role}'"
              else
                alter_statement = "ALTER SERVER ROLE #{sql_role} #{role_action} MEMBER [#{@new_resource.username}]"
              end
              Chef::Log.info("#{@new_resource} revoking server role membership with statement [#{alter_statement}]")
            end
            db.execute(alter_statement).do
          end
          @new_resource.updated_by_last_action(true)
        ensure
          close
        end

        private

        def exists?(type = :users)
          case type
          when :users
            table = 'database_principals'
            if @new_resource.database_name
              Chef::Log.debug("#{@new_resource} searching for existing user in '#{@new_resource.database_name}' database context.")
              db.execute("USE [#{@new_resource.database_name}]").do
            end
          when :logins
            table = 'server_principals'
          end

          result = db.execute("SELECT name FROM sys.#{table} WHERE name='#{@new_resource.username}'")
          result.each.any?
        end
      end
    end
  end
end
